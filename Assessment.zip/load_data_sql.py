from mysql.connector import connect, Error
import logging
from sqlalchemy import create_engine

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def load_data(tablename, df):
    try:
        engine = create_engine("mysql://root:candidate_passrd@db/test_db")
        con = engine.connect()
        dataFrame = df
        print(dataFrame)
        frame = dataFrame.to_sql(tablename, con, if_exists='append')
        status_code = 200
        message = "Data Loaded successfully for " + tablename
        con.close()
    except Error as e:
        print(e)
        logger.error(e)
        status_code = 500
        message = e

    return status_code, message