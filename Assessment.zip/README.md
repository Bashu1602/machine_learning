# take-home-de-forge

Forge Data Engineering Take Home

## Instructions

The [Autodesk Forge Platform](https://forge.autodesk.com/) enables Autodesk customers and partners to develop new applications that leverage [Forge services and APIs](https://forge.autodesk.com/en/docs/) to solve customer problems. This Take Home assessment for Data Engineers involves loading and transforming some of the non-production logs to provide an Analytics dataset that can be queried to provide insights.

This exercise should take from 1-4 hours given the structure and existing contents provided. Please do not take more than 4 hours on this take home exercise.

*At the end, please provide the following to robert.dibetta@autodesk.com*

1. Link to your repo (or a .zip file that contains your code and results (everything))
2. Description of much you completed and why and how long it took
3. SQL queries and SQL results for the questsions #1 through #4
4. Text answers to the questions a-d
5. Compressed Backup of your SQL db
6. Any additional info you wish to share

## Contents

* [/data/logs/FORGEAPI-S-UE1-firehose-delivery-stream-2-2021-10-31-Archive.zip](data/logs/FORGEAPI-S-UE1-firehose-delivery-stream-2-2021-10-31-Archive.zip) are the logs that should be ingested and transformed for analytics data
* [/data/schema/ul_schema.json](data/schema/ul_schema.json) describes the schema of the logs providing key field names and descriptions
* Docker files and Docker-Compose file
  
## Job Description

* External - [Senior Data Engineer](https://autodesk.wd1.myworkdayjobs.com/en-US/Ext/job/San-Francisco-CA-USA/Senior-Data-Engineer_21WD53332-2)

## take-home task

### task description

This repo provides a starting point with 2 working containers:

1. Container running MySQL (if you prefer you can replace this with a container that runs PostgreSQL)
   1. Database to store Analytics data
   2. Run SQL queries against this Analytics data and provide responses to questions below
2. Container to run Python for basic Data Pipeline
   1. Run process to load data
   2. Run process to perform any additional tasks

You are expected to create a database table and load with the data from the Json files in the "Contents" section of this ReadMe file. The schema provided explains the fields of the logs.

The mysql database should run in a docker container and all of the logic that you will be using for transforming the data should also be in a python enviroment inside of the Python docker container. You may add and use other tools such as PySpark or DBT or other libraries for your Python code.

For the ingestion steps and transformation, please implement in such a way that it could be run repeatedly to gather and process data regularly. Do not run any commands directly on the container that is running the MySQL database.

Once you have created the mysql table/s you are expected to answer some questions outlined below.

Please fork this REPO and create and run code to ingest and transform the data to be able to answer the following questions below by creating and running SQL queries against the data you've ingested.

*Please provide SQL Queries and SQL responses for the following*

1. Maximum and Average *apg_total_response_time* of each API based on the *endpoint_pattern*

select `ul_log_data.endpoint_pattern`, MAX(`ul_log_data.apg_total_response_time`) as value, 'MAX' as description from FORGEAPI_LOGS group by `ul_log_data.endpoint_pattern`
UNION ALL
select `ul_log_data.endpoint_pattern`, AVG(`ul_log_data.apg_total_response_time`) as value, 'AVG' as description from FORGEAPI_LOGS group by `ul_log_data.endpoint_pattern` order by `ul_log_data.endpoint_pattern`;

2. Error Ratio based on *apg_response_status_code* of each API based on the *endpoint_pattern*

select `ul_log_data.endpoint_pattern`, ROUND(SUM(CASE WHEN `ul_log_data.apg_response_status_code` = 200 then 1 else 0 end) / count(*),2) as error_ratio from FORGEAPI_LOGS group by `ul_log_data.endpoint_pattern`;

3. Number of unique API_Products (based on *apg_api_product*) that are making requests for each API based on the *endpoint_pattern*

select COUNT(DISTINCT `ul_log_data.apg_api_product`, `ul_log_data.endpoint_pattern`) from FORGEAPI_LOGS where `ul_log_data.apg_api_product` is NOT NULL and `ul_log_data.endpoint_pattern` is NOT NULL;

4. Developer App which experienced the worst latency with the latency provided in seconds

select `ul_log_data.apg_developer_app`, latency from(select *, RANK() OVER(ORDER BY latency desc) rnk from (select `ul_log_data.apg_developer_app`, `ul_log_data.apg_request_processing_latency` + `ul_log_data.apg_response_processing_latency` as latency from FORGEAPI_LOGS) temp)temp2 where temp2.rnk=1;

Answer:- Queries written in queries.txt that runs against query_run.py once the data is processed and loaded by logs_process.py. The output is stored in queries_output.txt

*Questions to Answer*

* a. Description of much you completed and why and how long it took

Created 3 python scripts one(logs_process.py) for Extract and Transformation, second(load_data_sql.py) for loading and (query_run.py) for running SQL queries. It took close to 2 hours 30 minutes to create the code, run and test it and initial 15 minutes for approach decision. 
Tasks breakdown:- Unzipping logs, differentiating between valid and invalid logs, transforming logs based on field nullability checks, load data and running queries.

* b. What method and tools did you use to ingest and transform the data and why?

Mostly used python libraries to unzip, validate and pandas dataframe to load data. Tried to create generic code that can run repeatedly.

* c. What steps might you do to avoid problems with customer Personally Identifiable Data? For example, If Autodesk * 
Forge Data needs to be GDPR compliant and not need to take actions against data once ingested, what must be done and how?

Masking and shuffling values which makes it difficult to decode. Also, data across DEV and QA databases shouldn't match from PROD.

* d. What were the 3 most difficult challenges faced and how did you resolve them?

1) How to handle valid and invalid logs, seggregate them and archive it once they are processed
2) pandas and pyspark:- Initially thought of using pyspark dataframes and load it mysql database but the challenge was to normalize the data and remove the map datatype. Achieved it but couldn't connect to MySQL server as mysql-connector-jdbc jar file was not getting installed. Hence, went ahead using pandas dataframe.
3) Setting up containers:- This was the most tedious thing and I had to switch my task from Windows to office MAC laptop

*At the end, please provide the following to robert.dibetta@autodesk.com*

1. Link to your repo (or a .zip file that contains your code and results (everything))
2. SQL queries and SQL results from numbered questsions above
3. Text answers to the questions a-d
4. Compressed Backup of your SQL db
5. Any additional info you wish to share

### How to make the docker-compose run

1. in the same folder where the docker-compose.yml is execute the command below
    1. docker-compose up
    2. you should see the next text in the terminal
    ![docker compose terminal](img/dockerComposeTerminal.png)
    3. In another terminal you should see the two containers that we will need for the take-home-task, execute the command below.
    ![docker containers](img/dockerContainers.png)
2. using container as remote servers
    1. https://www.youtube.com/watch?v=8gUtN5j4QnY
3. at the end, you can run ```docker-compose down``` to shutdown the containers after you have taken a db backup
