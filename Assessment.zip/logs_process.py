""" Module containing ETL logic for Autodesk Forge Platform"""
import glob
import json
import logging
import os
from zipfile import ZipFile
import pandas as pd
import shutil
import load_data_sql

logger = logging.getLogger()
logger.setLevel(logging.INFO)

"""Main logic starts here"""
def main(zip_log_path, final_log_path, processed_log_path, file_base_name, tablename):
    fullpath = os.path.join(zip_log_path, file_base_name)
    log_zip_list = glob.glob(fullpath + '*.zip')
    if log_zip_list:
        for zip_file in log_zip_list:
            with ZipFile(zip_file, 'r') as zipObj:
                # Extract all the logs of zip file in unprocessed_logs directory
                zipObj.extractall(final_log_path)
                if not os.listdir(final_log_path):
                    message="Failed unzipping the file"
                    logger.error(message)
                log_file_list = glob.glob(final_log_path + '*') # Fetch all the log files
                dfs = []
                # Iterate through each log file
                for log_file in log_file_list: 
                    if os.path.isdir(log_file):
                        continue
                    file1 = open(log_file, 'r')
                    # Iterate through each record of each log file for data validation
                    for record in file1:
                        status_code, message, flag = transform_data(record, log_file, final_log_path, processed_log_path)
                        if flag == 'valid':
                            dfs.append(json.loads(record))
                        else:
                            continue
                df = pd.json_normalize(dfs) # Normalize map type JSON data
                status_code, message = load_data_sql.load_data(tablename, df)
                if status_code == 200:
                    for proc_file in log_file_list:
                        processed_file = os.path.basename(proc_file)
                        processed_file_path = os.path.join(processed_log_path, processed_file)
                        if not os.path.isdir(processed_log_path):
                            os.mkdir(processed_log_path)
                            shutil.move(proc_file, processed_file_path) # Move processed log files to Archive folder
                        else:
                            shutil.move(proc_file, processed_file_path) # Move processed log files to Archive folder

    else:
        message="No log zip files available"
        logger.info(message)
        status_code = 200 
    
    response = {
        "statusCode": status_code,
        "message": message,
    }
    print(response)
    return status_code, message

def transform_data(data, log_file, final_log_path, processed_log_path):
    """Segreggate data into valid and invalid logs based on data validation"""
    try:
        json_data = json.loads(data)
    except ValueError as err:
        message = "Error parsing json log record"
        logger.error("%s", err)
        status_code = 500
    else:
        if((json_data['ul_span_id'] is not None and json_data['ul_operation'] is not None and json_data['ul_ctx_head_span_id'] is not None and json_data['ul_log_data'] is not None and json_data['ul_log_data']['cur_service_name'] is not None) and (json_data['ul_span_start'] is not None or json_data['ul_timestamp_epoch'] is not None)):
            status_code, message, flag = load_valid_logs(processed_log_path,log_file,json_data)
        else:
            status_code, message, flag = load_invalid_logs(final_log_path,log_file,json_data)
    return message, status_code, flag


def load_invalid_logs(final_log_path, log_file, json_record):
    """Processing Invalid Logs"""
    file = os.path.basename(log_file)
    full_path_invalid = final_log_path + file + '_invalid'
    a = []
    if not os.path.isfile(full_path_invalid):
        a.append(json_record)
        with open(full_path_invalid, mode='w') as f:
            f.write(json.dumps(a))
        message = "Created file and loaded invalid log"
        status_code = 200
        flag = 'invalid'
    else:
        with open(full_path_invalid) as json_file:
            rec = json.load(json_file)
        rec.append(json_record)
        with open(full_path_invalid, mode='w') as f:
            f.write(json.dumps(rec))
        message = "Appended invalid log"
        status_code = 200
        flag = 'invalid'
    return message, status_code, flag 

def load_valid_logs(processed_log_path, log_file, json_record):
    """Processing Valid Logs"""
    file = os.path.basename(log_file)
    full_path_valid = processed_log_path + file + '_valid'
    if not os.path.isdir(processed_log_path):
        os.mkdir(processed_log_path)
    a = []
    if not os.path.isfile(full_path_valid):
        a.append(json_record)
        with open(full_path_valid, mode='w') as f:
            f.write(json.dumps(a))
        message = "Created file and loaded valid log"
        status_code = 200
        flag = 'valid'
    else:
        with open(full_path_valid) as json_file:
            rec = json.load(json_file)
        rec.append(json_record)
        with open(full_path_valid, mode='w') as f:
            f.write(json.dumps(rec))
        message = "Appended valid log"
        status_code = 200
        flag = 'valid'
    return message, status_code, flag

if __name__ == "__main__":
    main('/app/data/logs/','/app/data/unprocessed_logs/', '/app/data/processed_logs/', 'FORGEAPI', 'FORGEAPI_LOGS')