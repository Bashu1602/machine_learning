from mysql.connector import connect, Error
try:
    with connect(
        host="db",
        user="root",
        password="candidate_passrd",
        database="test_db"
    ) as connection:
        print(connection)
        create_db_query = 'show tables'
        with connection.cursor() as cursor:
            cursor.execute(create_db_query)
            for table in cursor:
                print(table)
except Error as e:
    print(e)
    