from mysql.connector import connect, Error
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def main(query_file, query_output):
    try:
        with connect(
            host="db",
            user="root",
            password="candidate_passrd",
            database="test_db"
            ) as connection:
            fd = open(query_file,'r')
            sqlFile = fd.read()
            fd.close()
            sql_commands =  sqlFile.split(';')
            count = 1
            for command in sql_commands:
                db_query = command
                with connection.cursor() as cursor:
                    cursor.execute(db_query)
                    result = cursor.fetchall()
                    f = open(query_output, "a")
                    f.write('Query ' + str(count) +' Output:- ')
                    f.write(str(result))
                    f.close()
                count +=1
    except Error as e:
        print(e)
        logger.error(e)
        status_code = 500

if __name__ == "__main__":
    main('queries.txt', 'queries_output.txt')